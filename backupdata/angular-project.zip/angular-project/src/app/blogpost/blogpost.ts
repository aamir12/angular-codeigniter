export class Blogpost {
    id: number;
    title: string;
    short_desc: string;
    author: string;
    image: string;
    created_at: Date;
}
